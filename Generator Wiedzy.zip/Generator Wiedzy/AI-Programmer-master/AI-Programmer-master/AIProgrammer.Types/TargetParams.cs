﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIProgrammer.Types
{
    public class TargetParams
    {
        public double TargetFitness { get; set; }
        public string TargetString { get; set; }
    };
}
